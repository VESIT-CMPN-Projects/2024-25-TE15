/* eslint-disable @typescript-eslint/no-require-imports */
const sharedConfig = require("@plane/tailwind-config/tailwind.config.js");

module.exports = {
  presets: [sharedConfig],
};
