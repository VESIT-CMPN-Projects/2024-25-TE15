from django.apps import AppConfig


class BgtasksConfig(AppConfig):
    name = "plane.bgtasks"
