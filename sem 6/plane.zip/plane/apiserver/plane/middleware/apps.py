from django.apps import AppConfig


class Middleware(AppConfig):
    name = "plane.middleware"
